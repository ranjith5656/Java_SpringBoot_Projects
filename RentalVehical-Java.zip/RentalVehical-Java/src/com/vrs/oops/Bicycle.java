package com.vrs.oops;

public class Bicycle extends Vehicle {
    private int numberOfGears;
    private boolean hasBasket;

    // Constructor
    public Bicycle() {
        this.setLicensePlate(licensePlate);
        this.setMake(make);
        this.setModel(model);
        this.setNumberOfGears(numberOfGears);
        this.setHasBasket(hasBasket);
        this.setAvailable(true);
    }

    // Getters and setters for Bicycle-specific properties
    public int getNumberOfGears() {
        return numberOfGears;
    }

    public void setNumberOfGears(int numberOfGears) {
        this.numberOfGears = numberOfGears;
    }

    public boolean hasBasket() {
        return hasBasket;
    }

    public void setHasBasket(boolean hasBasket) {
        this.hasBasket = hasBasket;
    }
    
    

    
    @Override
	public String toString() {
		return "Bicycle [numberOfGears=" + numberOfGears + ", hasBasket=" + hasBasket + "]";
	}

	public void ringBell() {
        System.out.println("Ring! Ring! The bicycle bell is ringing!");
    }

    public void pedal() {
        System.out.println("Pedaling the bicycle...");
    }
}




