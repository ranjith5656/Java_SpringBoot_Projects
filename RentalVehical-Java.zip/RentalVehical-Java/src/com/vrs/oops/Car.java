package com.vrs.oops;

public class Car extends Vehicle{
	
	 private int numberOfSeats;
	    private String fuelType;

	    // Constructor
	    public Car() {
	        this.setLicensePlate(licensePlate);
	        this.setMake(make);
	        this.setModel(model);
	        this.setNumberOfSeats(numberOfSeats);
	        this.setFuelType(fuelType);
	        this.setAvailable(true);
	    }

	    // Getters and setters for Car-specific properties
	    public int getNumberOfSeats() {
	        return numberOfSeats;
	    }

	    public void setNumberOfSeats(int numberOfSeats) {
	        this.numberOfSeats = numberOfSeats;
	    }

	    public String getFuelType() {
	        return fuelType;
	    }

	    public void setFuelType(String fuelType) {
	        this.fuelType = fuelType;
	    }
	    
	    

//	    @Override
//		public String toString() {
//			return "Car [numberOfSeats=" + numberOfSeats + ", fuelType=" + fuelType + "]";
//		}

		@Override
		public String toString() {
			return "Car [licensePlate=" + licensePlate + ", make=" + make + ", model=" + model + ", getNumberOfSeats()="
					+ getNumberOfSeats() + ", getFuelType()=" + getFuelType() + ", isAvailable()=" + isAvailable()
					+ ", getLicensePlate()=" + getLicensePlate() + ", getMake()=" + getMake() + ", getModel()="
					+ getModel() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
					+ super.toString() + "]";
		}

		// Car-specific methods
	    public void startEngine() {
	        System.out.println("Starting the car's engine...");
	    }

	    public void stopEngine() {
	        System.out.println("Stopping the car's engine...");
	    }

}
