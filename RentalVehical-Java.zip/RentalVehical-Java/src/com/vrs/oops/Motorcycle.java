package com.vrs.oops;

public class Motorcycle extends Vehicle {
	
	private int engineCapacity;

    public int getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(int engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public void startEngine() {
        System.out.println("Starting the motorcycle engine.");
    }

    public void stopEngine() {
        System.out.println("Stopping the motorcycle engine.");
    }

}
