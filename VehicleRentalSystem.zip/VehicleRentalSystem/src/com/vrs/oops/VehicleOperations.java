package com.vrs.oops;

public interface VehicleOperations {
	
	boolean isAvailable();
    void setAvailable(boolean isAvailable);

}
